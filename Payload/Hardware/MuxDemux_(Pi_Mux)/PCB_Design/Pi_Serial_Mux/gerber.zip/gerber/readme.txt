drill files identification:

The drill files are named as per the drill type information it provides (palted or non plated).

*Plate all holes (including vias) which have a hole size below 100mil.
 Do not plate holes which are above 200mil.

layer stackup:

Your default 2 layer stackup.


FAQ:

1. May we remove of non functional pads in inner layers? - There aren't any.
2. Adding copper thieving for better plating is allowed? - YES.
3. Is there any logo placement restrictions? - YES. (However you can place your tracking ID on the bottom side of the board)
4. May we add �teardrop� at trace and pad intersections? - NO.
5. May we rim void if a land appears where a non-plated through-hole is placed? - NO.
6. May we give gang opening to the fine pitch SMT packages if spacing does not permit for solder mask dam? - YES.
7. If hole size tolerances are not called out, may we use +/- 0.075 mm? - YES.
8. If PCB thickness tolerances are not called out, may we use +/- 10%? - YES.
9. If PCB size tolerance is not called out, may we use +/- 0.25 mm? - YES.